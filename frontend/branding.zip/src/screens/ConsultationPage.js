import React from 'react'
import Consultation from '../components/Consultation/Consultation'

const ConsultationPage = () => {
    return (
        <div>
            <Consultation />
        </div>
    )
}

export default ConsultationPage;