let Settings = {
  apiBaseUrl: '/api/sample'
}

export default Settings;