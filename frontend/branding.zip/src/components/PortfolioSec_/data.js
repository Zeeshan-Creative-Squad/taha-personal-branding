export const Data = [
  {
    id: "1",
    heading: "App Development",
    list: [
      { id: "1", img: "/images/app1.jpg" },
      { id: "2", img: "/images/app2.webp" },
      { id: "3", img: "/images/app3.webp" },
      { id: "4", img: "/images/app4.webp" },
      { id: "5", img: "/images/app5.webp" },
      { id: "6", img: "/images/app6.webp" },
      { id: "7", img: "/images/app7.webp" },
      { id: "8", img: "/images/app8.webp" },
      { id: "9", img: "/images/app9.webp" },
    ],
  },
  {
    id: "2",
    heading: "Ecom Development",
    list: [
      { id: "1", img: "/images/ecom1.webp" },
      { id: "2", img: "/images/ecom2.webp" },
      { id: "3", img: "/images/ecom3.webp" },
      { id: "4", img: "/images/ecom4.webp" },
      { id: "5", img: "/images/ecom5.webp" },
      { id: "6", img: "/images/ecom6.webp" },
      { id: "7", img: "/images/ecom7.webp" },
      { id: "8", img: "/images/ecom8.webp" },
      { id: "9", img: "/images/ecom9.webp" },
    ],
  },
];
