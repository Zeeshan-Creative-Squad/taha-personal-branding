import React, { Fragment } from "react"; 
import BlogsListings from "./BlogsListings";

const Blog = () => { 
  return (
    <Fragment>
      <BlogsListings />
    </Fragment>
  );
};

export default Blog;
